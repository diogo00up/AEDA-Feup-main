#include "../Header/SuitCase.h"
#include  <cstdlib>

SuitCase::SuitCase() {
}

