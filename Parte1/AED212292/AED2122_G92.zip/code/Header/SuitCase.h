#ifndef PROJ_SUITCASE_H
#define PROJ_SUITCASE_H

class SuitCase{
public:
    /**
     * Constructor
     */
    SuitCase();
};


#endif //PROJ_SUITCASE_H
