var searchData=
[
  ['ticket_374',['Ticket',['../class_ticket.html#a050ade72ca12dc001e4c16d9fd4ebdc1',1,'Ticket::Ticket(Flight *flight, Client *client, int ticketId, const vector&lt; SuitCase * &gt; &amp;suitCases, bool checkedIn, int nSuitCasesCheckIn)'],['../class_ticket.html#acaeb6ec3ade8645354c5a3c07c1acdff',1,'Ticket::Ticket(Flight *flight, Client *client, int ticketId, bool checkedIn, int nSuitCasesCheckIn)']]],
  ['transferluggagetocar_375',['transferLuggageToCar',['../class_managment_system.html#afe194534166a1c9469b6de14393fb213',1,'ManagmentSystem']]],
  ['transportationlocal_376',['TransportationLocal',['../class_transportation_local.html#ac98a8e9d7ec8d51365854b6fddf8c781',1,'TransportationLocal::TransportationLocal(int transportationLocalId, float distanceToAirport, TransportationType transportationType, Airport *airport)'],['../class_transportation_local.html#aea67e1291029fb9d6755393794d7e51a',1,'TransportationLocal::TransportationLocal(int transportationLocalId, float distanceToAirport, string transportationType, Airport *airport)']]]
];
