var searchData=
[
  ['worker_378',['Worker',['../class_worker.html#a5db6c774a6184436fab0dd7633bae969',1,'Worker']]]
];
