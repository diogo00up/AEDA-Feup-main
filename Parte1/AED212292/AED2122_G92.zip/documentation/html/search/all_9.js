var searchData=
[
  ['mainmenu_131',['MainMenu',['../class_menus.html#ac3d9e05ca5c62ad3881ef4bb57b313eb',1,'Menus']]],
  ['managmentsystem_132',['ManagmentSystem',['../class_managment_system.html',1,'']]],
  ['matchticketclient_133',['matchTicketClient',['../class_tickets_reg.html#a168f678c4b4fb287153d54dcf5b0fd03',1,'TicketsReg']]],
  ['menus_134',['Menus',['../class_menus.html',1,'']]]
];
