var searchData=
[
  ['date_44',['Date',['../class_date.html',1,'Date'],['../class_date.html#a4e59ed4ba66eec61c27460c5d09fa1bd',1,'Date::Date()'],['../class_date.html#a3c18cf6ead562e5bf45feeaa94ef853c',1,'Date::Date(string Date)'],['../class_date.html#a73ea91f53dc85192340ca332413c865f',1,'Date::Date(unsigned day, unsigned month, int year)'],['../class_date.html#ad60a06bab3db402303ea74ebc409ce29',1,'Date::Date(const Date &amp;date)']]],
  ['differencebetween_45',['differenceBetween',['../class_date.html#aaa938d8473d391e314d186823b280873',1,'Date']]]
];
