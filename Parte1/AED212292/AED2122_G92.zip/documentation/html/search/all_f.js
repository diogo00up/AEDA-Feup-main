var searchData=
[
  ['tapetereg_175',['TapeteReg',['../class_tapete_reg.html',1,'']]],
  ['ticket_176',['Ticket',['../class_ticket.html',1,'Ticket'],['../class_ticket.html#a050ade72ca12dc001e4c16d9fd4ebdc1',1,'Ticket::Ticket(Flight *flight, Client *client, int ticketId, const vector&lt; SuitCase * &gt; &amp;suitCases, bool checkedIn, int nSuitCasesCheckIn)'],['../class_ticket.html#acaeb6ec3ade8645354c5a3c07c1acdff',1,'Ticket::Ticket(Flight *flight, Client *client, int ticketId, bool checkedIn, int nSuitCasesCheckIn)']]],
  ['ticketsreg_177',['TicketsReg',['../class_tickets_reg.html',1,'']]],
  ['transferluggagetocar_178',['transferLuggageToCar',['../class_managment_system.html#afe194534166a1c9469b6de14393fb213',1,'ManagmentSystem']]],
  ['transportationlocal_179',['TransportationLocal',['../class_transportation_local.html',1,'TransportationLocal'],['../class_transportation_local.html#ac98a8e9d7ec8d51365854b6fddf8c781',1,'TransportationLocal::TransportationLocal(int transportationLocalId, float distanceToAirport, TransportationType transportationType, Airport *airport)'],['../class_transportation_local.html#aea67e1291029fb9d6755393794d7e51a',1,'TransportationLocal::TransportationLocal(int transportationLocalId, float distanceToAirport, string transportationType, Airport *airport)']]],
  ['transportationlocalreg_180',['TransportationLocalReg',['../class_transportation_local_reg.html',1,'']]]
];
